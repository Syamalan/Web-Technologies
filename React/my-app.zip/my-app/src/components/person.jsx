let Person = (props)=>{
    return <h2>Hi {props.pname}, I am {props.age} years old</h2>
    
}


export default Person

